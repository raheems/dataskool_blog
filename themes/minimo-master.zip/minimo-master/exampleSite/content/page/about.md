---
title: About
description: What does Minimo even means?!
menu: main
weight: -210
---

Mínimo is a Spanish word that roughly translate to Minimal.

Minimo is a minimalist theme for Hugo.

Minimo keeps the focus on your content and lets it shine!
