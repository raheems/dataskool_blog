---
date: 2017-09-28T08:00:00+06:00
title: Typography
authors: ["muniftanjim"]
slug: typography
menu: main
weight: -230
---
Here is a paragraph. **Lorem ipsum _dolor_ sit amet**, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

## Heading 2

Another one. Ut enim ad minim veniam, _quis nostrud exercitation **ullamco** laboris nisi ut aliquip ex ea commodo consequat_. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

{{% center %}}
### Heading 3

Yet another, but centered! Excepteur sint occaecat ~~cupidatat non proident, sunt in culpa qui officia~~ deserunt mollit anim id est laborum.
{{% /center %}}

#### Heading 4

1. First item
2. Second item
  - Nested unordered item
3. Third item
  1. Nested ordered item 1
  2. Nested ordered item 2

##### Heading 5

Where are the quotes!!!

> Simplify, then add lightness.  
— Colin Chapman

Now, [time for some links](/typography#heading-5)!

- [GoHugo]
 - [Hugo Themes][1]

[GoHugo]: https://gohugo.io
[1]: https://themes.gohugo.io/

###### Heading 6

Inline code: `echo "What is the meaning of life?"`. Who knows?

```javascript
// Codeblock

var meaningOfLife = 42;
console.log('The meaning of life is: ', meaningOfLife);
```

---

Who wants some table?

  Minimo  |  Caption  | More Caption
 -------- | --------- | ------------
   Cool   |   What?   |  Now, wut?!


Ah, enough for today, eh?
