---
title: Home
menu:
  - main
  - sidebar
weight: -270
---
> Minimalism is not a lack of something. It’s simply the perfect amount of something.
> — Nicholas Burroughs
